﻿namespace lab13v1.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; } = string.Empty;
        public float Price { get; set; }
        public bool IsActive { get; set; } = true;

    }
}
