﻿using System.Text.Json.Serialization;

public class Invoice
{
    public int InvoiceId { get; set; }
    public DateTime Date { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public float Total { get; set; }
    public bool IsActive { get; set; } = true;

    public int CustomerId { get; set; }

    [JsonIgnore] // <- para evitar error 500 en Swagger
    public Customer? Customer { get; set; }
}
