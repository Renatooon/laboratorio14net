﻿namespace lab13v1.Requests
{
    public class CustomerDocumentUpdateRequestV1
    {
        public int Id { get; set; }
        public string DocumentNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
