﻿namespace lab13v1.Requests
{
    public class ProductRequestV1
    {

        public string Name { get; set; } = string.Empty;
        public float Price { get; set; }

    }
}
