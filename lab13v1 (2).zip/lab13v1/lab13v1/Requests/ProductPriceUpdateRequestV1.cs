﻿namespace lab13v1.Requests
{
    public class ProductPriceUpdateRequestV1
    {
        public int Id { get; set; }
        public float Precio { get; set; }
        public string LastName { get; set; } = string.Empty; // Nota: ¿Está relacionado a un cliente?
    }
}
