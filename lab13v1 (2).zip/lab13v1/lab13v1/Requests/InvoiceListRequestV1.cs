﻿namespace lab13v1.Requests
{
    public class InvoiceListRequestV1
    {
        public int IdCliente { get; set; }
        public List<InvoiceItemRequest> Invoices { get; set; } = new();
    }

    public class InvoiceItemRequest
    {
        public DateTime Date { get; set; }
        public string InvoiceNumber { get; set; } = string.Empty;
        public float Total { get; set; }
    }
}
