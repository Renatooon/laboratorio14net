﻿namespace lab13v1.Requests
{
    public class InvoiceRequestV1
    {
        public int IdCustomer { get; set; }
        public DateTime Date { get; set; }
        public string InvoiceNumber { get; set; } = string.Empty;
        public float Total { get; set; }
    }
}
