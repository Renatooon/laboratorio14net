﻿using lab13v1.Requests;

namespace lab13v1.Requests
{
    public class InvoiceDetailRequestV1
    {
        // FK al producto
        public int IdProduct { get; set; }
        public int Amount { get; set; }
        public float Price { get; set; }          // precio unitario
    }
}

public class InvoiceDetailListRequestV1
{
    public int IdInvoice { get; set; }
    public List<InvoiceDetailRequestV1> Details { get; set; } = new();
}
