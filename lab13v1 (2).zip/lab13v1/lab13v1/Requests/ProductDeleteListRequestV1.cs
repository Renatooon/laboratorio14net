﻿namespace lab13v1.Requests
{

    public class ProductDeleteListRequestV1
    {
        public List<int> IdProducts { get; set; } = new();
    }
}
