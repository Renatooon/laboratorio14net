﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab13v1.Data;
using lab13v1.Models;
using lab13v1.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace lab13v1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly CustomerContext _context;

        public ProductsController(CustomerContext context)
        {
            _context = context;
        }

        // GET: api/Products/GetAll
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetAll()
        {
            return await _context.Products
                                 .Where(p => p.IsActive)
                                 .ToListAsync();
        }

        // GET: api/Products/GetById/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetById(int id)
        {
            var product = await _context.Products
                                        .FirstOrDefaultAsync(p => p.ProductId == id && p.IsActive);
            if (product == null)
                return NotFound();

            return product;
        }

        // PUT: api/Products/Update/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Product product)
        {
            if (id != product.ProductId)
                return BadRequest();

            var existing = await _context.Products.FindAsync(id);
            if (existing == null || !existing.IsActive)
                return NotFound();

            _context.Entry(existing).CurrentValues.SetValues(product);
            existing.IsActive = true;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!ProductExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        // DELETE lógica: api/Products/Delete/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null || !product.IsActive)
                return NotFound();

            product.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: api/Products/Insert
        [HttpPost]
        public IActionResult Insert(ProductRequestV1 request)
        {
            _context.Products.Add(new Product
            {
                Name = request.Name,
                Price = request.Price,
                IsActive = true
            });

            _context.SaveChanges();

            return Ok(new { message = "Producto insertado correctamente" });
        }

        // POST: api/Products/InsertGroup
        [HttpPost]
        public IActionResult InsertGroup(List<ProductRequestV1> request)
        {
            var model = request.Select(x => new Product
            {
                Name = x.Name,
                Price = x.Price,
                IsActive = true
            }).ToList();

            _context.Products.AddRange(model);
            _context.SaveChanges();

            return Ok(new { message = "Productos insertados correctamente", count = model.Count });
        }

        [HttpPut]
        public IActionResult UpdatePrice(ProductPriceUpdateRequestV1 request)
        {
            var product = _context.Products.FirstOrDefault(x => x.ProductId == request.Id && x.IsActive);
            if (product == null)
                return NotFound("Producto no encontrado o inactivo");

            product.Price = request.Precio;
            _context.SaveChanges();

            return Ok("Precio actualizado correctamente");
        }


        [HttpPut]                 // o [HttpPost] si prefieres
        public IActionResult DeleteList(ProductDeleteListRequestV1 request)
        {
            if (request.IdProducts is null || request.IdProducts.Count == 0)
                return BadRequest("La lista no puede estar vacía.");

            // Traemos solo los productos activos cuyo id esté en la lista
            var products = _context.Products
                                   .Where(p => request.IdProducts.Contains(p.ProductId) && p.IsActive)
                                   .ToList();

            if (products.Count == 0)
                return NotFound("Ningún producto activo coincide con los Id proporcionados.");

            // Soft-delete
            products.ForEach(p => p.IsActive = false);
            _context.SaveChanges();

            return Ok(new
            {
                message = "Productos desactivados correctamente.",
                affected = products.Count
            });
        }

        private bool ProductExists(int id)
            => _context.Products.Any(e => e.ProductId == id && e.IsActive);
    }
}
