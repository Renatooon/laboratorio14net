﻿using Microsoft.AspNetCore.Mvc;
using lab13v1.Data;
using lab13v1.Models;
using lab13v1.Requests;

namespace lab13v1.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class InvoicesCustomController : ControllerBase
    {
        private readonly CustomerContext _context;

        public InvoicesCustomController(CustomerContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult InsertDetails(InvoiceDetailListRequestV1 request)

        {
            var invoice = _context.Invoices
                .FirstOrDefault(i => i.InvoiceId == request.IdInvoice && i.IsActive);

            if (invoice == null)
                return NotFound("Factura no encontrada o inactiva.");

            var details = request.Details.Select(d => new Detail
            {
                InvoiceId = request.IdInvoice,
                ProductId = d.IdProduct,
                Amount = d.Amount,
                Price = d.Price,
                SubTotal = d.Amount * d.Price,
                IsActive = true
            }).ToList();

            _context.Details.AddRange(details);
            _context.SaveChanges();

            return Ok(new { message = "Detalles insertados.", count = details.Count });
        }
    }
}
