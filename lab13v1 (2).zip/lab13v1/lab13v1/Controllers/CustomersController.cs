﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using lab13v1.Data;
using lab13v1.Models;

namespace lab13v1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly CustomerContext _context;

        public CustomersController(CustomerContext context)
        {
            _context = context;
        }

        // GET: api/Customers
        // Sólo devuelve clientes activos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            return await _context.Customers
                                 .Where(c => c.IsActive)
                                 .ToListAsync();
        }

        // GET: api/Customers/5
        // Sólo encuentra el cliente si está activo
        [HttpGet("{id}")]
        public async Task<ActionResult<Customer>> GetCustomer(int id)
        {
            var customer = await _context.Customers
                                         .FirstOrDefaultAsync(c => c.CustomerId == id && c.IsActive);

            if (customer == null)
                return NotFound();

            return customer;
        }

        // PUT: api/Customers/5
        // Actualiza sólo si existe y está activo
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomer(int id, Customer customer)
        {
            if (id != customer.CustomerId)
                return BadRequest();

            // Comprobamos que exista y esté activo
            var existing = await _context.Customers.FindAsync(id);
            if (existing == null || !existing.IsActive)
                return NotFound();

            // Actualizamos sólo los campos editables
            existing.FirstName = customer.FirstName;
            existing.LastName = customer.LastName;
            existing.DocumentNumber = customer.DocumentNumber;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!CustomerExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        // POST: api/Customers
        // Crea un cliente con IsActive = true por defecto
        [HttpPost]
        public async Task<ActionResult<Customer>> PostCustomer(Customer customer)
        {
            customer.IsActive = true;
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCustomer), new { id = customer.CustomerId }, customer);
        }

        // DELETE: api/Customers/5
        // Soft delete: marca IsActive = false
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer == null || !customer.IsActive)
                return NotFound();

            customer.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Sólo considera clientes activos
        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.CustomerId == id && e.IsActive);
        }
        // GET: api/Customers/search/{name}
        // Busca clientes activos cuyo FirstName contenga el texto indicado (case-insensitive)
        [HttpGet("search/{name}")]
        public async Task<ActionResult<IEnumerable<Customer>>> SearchByName(string name)
        {
            var matches = await _context.Customers
                .Where(c => c.IsActive &&
                            EF.Functions.Like(c.FirstName, $"%{name}%"))
                .ToListAsync();

            if (matches.Count == 0)
                return NotFound();   // o simplemente: return matches;

            return matches;
        }
    }
}