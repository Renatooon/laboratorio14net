﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using lab13v1.Data;
using lab13v1.Models;

namespace lab13v1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetailsController : ControllerBase
    {
        private readonly CustomerContext _context;

        public DetailsController(CustomerContext context)
        {
            _context = context;
        }

        // GET: api/Details
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Detail>>> GetDetails()
        {
            return await _context.Details
                                 .Where(d => d.IsActive)
                                 .ToListAsync();
        }

        // GET: api/Details/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Detail>> GetDetail(int id)
        {
            var detail = await _context.Details
                                       .FirstOrDefaultAsync(d => d.DetailId == id && d.IsActive);
            if (detail == null)
                return NotFound();

            return detail;
        }

        // PUT: api/Details/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDetail(int id, Detail detail)
        {
            if (id != detail.DetailId)
                return BadRequest();

            var existing = await _context.Details.FindAsync(id);
            if (existing == null || !existing.IsActive)
                return NotFound();

            // Sobrescribimos sólo las propiedades (sin cambiar IsActive ni el PK)
            _context.Entry(existing).CurrentValues.SetValues(detail);
            existing.IsActive = true;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!DetailExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        // POST: api/Details
        [HttpPost]
        public async Task<ActionResult<Detail>> PostDetail(Detail detail)
        {
            detail.IsActive = true;
            _context.Details.Add(detail);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetDetail), new { id = detail.DetailId }, detail);
        }

        // DELETE: api/Details/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetail(int id)
        {
            var detail = await _context.Details.FindAsync(id);
            if (detail == null || !detail.IsActive)
                return NotFound();

            detail.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DetailExists(int id)
            => _context.Details.Any(e => e.DetailId == id && e.IsActive);
    }
}