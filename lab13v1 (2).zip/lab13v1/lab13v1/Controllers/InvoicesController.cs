﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using lab13v1.Data;
using lab13v1.Models;
using lab13v1.Requests;

namespace lab13v1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoicesController : ControllerBase
    {
        private readonly CustomerContext _context;

        public InvoicesController(CustomerContext context)
        {
            _context = context;
        }

        // GET: api/Invoices
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Invoice>>> GetInvoices()
        {
            return await _context.Invoices
                                 .Where(i => i.IsActive)
                                 .ToListAsync();
        }

        // GET: api/Invoices/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Invoice>> GetInvoice(int id)
        {
            var invoice = await _context.Invoices
                                        .FirstOrDefaultAsync(i => i.InvoiceId == id && i.IsActive);
            if (invoice == null)
                return NotFound();

            return invoice;
        }

        // PUT: api/Invoices/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutInvoice(int id, Invoice invoice)
        {
            if (id != invoice.InvoiceId)
                return BadRequest();

            var existing = await _context.Invoices.FindAsync(id);
            if (existing == null || !existing.IsActive)
                return NotFound();

            _context.Entry(existing).CurrentValues.SetValues(invoice);
            existing.IsActive = true;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!InvoiceExists(id))
            {
                return NotFound();
            }

            return NoContent();
        }

        // POST: api/Invoices
        [HttpPost]
        public async Task<ActionResult<Invoice>> PostInvoice(Invoice invoice)
        {
            invoice.IsActive = true;
            _context.Invoices.Add(invoice);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetInvoice), new { id = invoice.InvoiceId }, invoice);
        }

        // POST: api/Invoices/InsertCustom
        [HttpPost("InsertCustom")]
        public async Task<IActionResult> InsertCustom(InvoiceRequestV1 request)
        {
            var invoice = new Invoice
            {
                CustomerId = request.IdCustomer,
                Date = request.Date,
                InvoiceNumber = request.InvoiceNumber,
                Total = request.Total,
                IsActive = true
            };

            _context.Invoices.Add(invoice);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Factura insertada correctamente", invoice.InvoiceId });
        }

        // DELETE: api/Invoices/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInvoice(int id)
        {
            var invoice = await _context.Invoices.FindAsync(id);
            if (invoice == null || !invoice.IsActive)
                return NotFound();

            invoice.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost]
        [Route("InsertGroupByCustomer")]
        public IActionResult InsertGroupByCustomer([FromBody] InvoiceListRequestV1 request)
        {
            var customer = _context.Customers.FirstOrDefault(c => c.CustomerId == request.IdCliente && c.IsActive);
            if (customer == null)
                return NotFound("Cliente no encontrado");

            var invoices = request.Invoices.Select(i => new Invoice
            {
                Date = i.Date,
                InvoiceNumber = i.InvoiceNumber,
                Total = i.Total,
                CustomerId = request.IdCliente,
                IsActive = true
            }).ToList();

            _context.Invoices.AddRange(invoices);
            _context.SaveChanges();

            return Ok("Facturas registradas correctamente");
        }

        private bool InvoiceExists(int id)
            => _context.Invoices.Any(e => e.InvoiceId == id && e.IsActive);
    }
}
